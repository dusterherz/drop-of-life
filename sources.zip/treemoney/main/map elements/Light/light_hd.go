embedded_components {
  id: "light_hd"
  type: "sprite"
  data: "tile_set: \"/main/map elements/Light/light_hd.atlas\"\n"
  "default_animation: \"Light_HD\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "blend_mode: BLEND_MODE_ALPHA\n"
  ""
  position {
    x: 160.0
    y: 90.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
