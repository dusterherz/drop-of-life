embedded_components {
  id: "light_bg"
  type: "sprite"
  data: "tile_set: \"/main/map elements/Light/light_bg.atlas\"\n"
  "default_animation: \"Light_BG\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "blend_mode: BLEND_MODE_ALPHA\n"
  ""
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
