embedded_components {
  id: "shadow_tree"
  type: "sprite"
  data: "tile_set: \"/main/map elements/shadow_tree/shadow_tree.atlas\"\n"
  "default_animation: \"shadow_tree\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "blend_mode: BLEND_MODE_ALPHA\n"
  ""
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
