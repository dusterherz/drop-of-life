embedded_components {
  id: "grass"
  type: "sprite"
  data: "tile_set: \"/main/map elements/grass/grass.atlas\"\n"
  "default_animation: \"grass\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "blend_mode: BLEND_MODE_ALPHA\n"
  ""
  position {
    x: 0.0
    y: 0.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
